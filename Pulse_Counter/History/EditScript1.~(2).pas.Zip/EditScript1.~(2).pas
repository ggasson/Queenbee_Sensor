{-----------------------------------------------------------------------------
  Create_Universal_Pulse_Input.pas
  Single-channel 24V universal (PNP/NPN) pulse input schematic generator.

  Fix: Avoid SchDoc.DM_FileName. Use Client.CreateDocument + GetCurrentSchDocument.
-----------------------------------------------------------------------------}

procedure PlaceNetLabel(SchDoc : ISch_Document; const NetName : string; X, Y : Integer);
var
  NL : ISch_NetLabel;
begin
  NL := SchServer.SchObjectFactory(eNetLabel, eCreate_Default);
  NL.Text := NetName;
  NL.Location := Point(X, Y);
  SchDoc.AddSchObject(NL);
end;

procedure PlaceGenericComponent(SchDoc : ISch_Document;
  const Des, Comment, LibRef : string; X, Y : Integer);
var
  C : ISch_Component;
begin
  C := SchServer.SchObjectFactory(eSchComponent, eCreate_Default);
  C.Designator.Text := Des;
  C.Comment.Text := Comment;

  { If you know your library reference, set it here }
  if LibRef <> '' then
    C.LibReference := LibRef;

  C.Location := Point(X, Y);
  SchDoc.AddSchObject(C);
end;

procedure BuildSheet;
var
  Doc   : IServerDocument;
  SchDoc: ISch_Document;
  X0, Y0: Integer;
begin
  { Create a new schematic document via Client (NOT SchServer.CreateNewDocument) }
  Doc := Client.CreateDocument('SCH', '');
  if Doc = nil then exit;

  Client.ShowDocument(Doc);

  { Now get the active schematic document }
  SchDoc := SchServer.GetCurrentSchDocument;
  if SchDoc = nil then
  begin
    ShowMessage('No active schematic document found. Make sure a SCH is open/active.');
    exit;
  end;

  SchServer.ProcessControl.PreProcess(SchDoc, '');
  try
    X0 := 1000;
    Y0 := 1000;

    { J1 - 3 pin field terminal }
    PlaceGenericComponent(SchDoc, 'J1', 'FIELD_TERMINAL_3P (+24V_F, SIG, 0V_F)', '', X0, Y0);

    { Input protection + filter }
    PlaceGenericComponent(SchDoc, 'TVS1', 'SMBJ33A', '', X0+1400, Y0-200);
    PlaceGenericComponent(SchDoc, 'R1', '10k',     '', X0+1400, Y0+200);
    PlaceGenericComponent(SchDoc, 'C1', '2.2nF',   '', X0+2000, Y0+600);

    { Divider }
    PlaceGenericComponent(SchDoc, 'R2', '1.0M',    '', X0+2600, Y0+200);
    PlaceGenericComponent(SchDoc, 'R3', '200k',    '', X0+2600, Y0+700);

    { VREF divider from +5V_F }
    PlaceGenericComponent(SchDoc, 'R4', '150k',    '', X0+4200, Y0-200);
    PlaceGenericComponent(SchDoc, 'R5', '100k',    '', X0+4200, Y0+300);

    { Comparator }
    PlaceGenericComponent(SchDoc, 'U1', 'Comparator (LMV331/TLV1701)', '', X0+5200, Y0+250);

    { Hysteresis resistor }
    PlaceGenericComponent(SchDoc, 'R6', '4.7M (hysteresis)', '', X0+6400, Y0+250);

    { Digital isolator }
    PlaceGenericComponent(SchDoc, 'U2', 'Digital Isolator (ISO7721/ADuM1201)', '', X0+7600, Y0+250);

    { Net labels }
    PlaceNetLabel(SchDoc, '+24V_F',    X0+200,  Y0-500);
    PlaceNetLabel(SchDoc, 'SIG',       X0+200,  Y0-200);
    PlaceNetLabel(SchDoc, '0V_F',      X0+2_

