procedure PlaceNetLabel(SchDoc : ISch_Document; const NetName : string; X, Y : Integer);
var
  NL : ISch_NetLabel;
begin
  NL := SchServer.SchObjectFactory(eNetLabel, eCreate_Default);
  NL.Text := NetName;
  NL.Location := Point(X, Y);
  SchDoc.AddSchObject(NL);
end;

procedure PlaceTextFrame(SchDoc : ISch_Document; const S : string; X, Y : Integer);
var
  TF : ISch_TextFrame;
begin
  TF := SchServer.SchObjectFactory(eTextFrame, eCreate_Default);
  TF.Text := S;
  TF.Location := Point(X, Y);
  SchDoc.AddSchObject(TF);
end;

procedure Main;
var
  SchDoc: ISch_Document;
  X0, Y0: Integer;
begin
  SchDoc := SchServer.GetCurrentSchDocument;
  if SchDoc = nil then
  begin
    ShowMessage('No active schematic. Open/click a SCH and run again.');
    exit;
  end;

  SchServer.ProcessControl.PreProcess(SchDoc, '');
  try
    X0 := 1000;
    Y0 := 1000;

    PlaceNetLabel(SchDoc, '+24V_F',    X0+200,  Y0-500);
    PlaceNetLabel(SchDoc, 'SIG',       X0+200,  Y0-200);
    PlaceNetLabel(SchDoc, '0V_F',      X0+200,  Y0+100);

    PlaceNetLabel(SchDoc, 'SENSE_RAW', X0+1800, Y0+200);
    PlaceNetLabel(SchDoc, 'SENSE',     X0+3000, Y0+450);
    PlaceNetLabel(SchDoc, 'VREF',      X0+4500, Y0+80);

    PlaceNetLabel(SchDoc, '+5V_F',     X0+4000, Y0-600);

    PlaceNetLabel(SchDoc, 'ISO_IN',    X0+7100, Y0+250);
    PlaceNetLabel(SchDoc, 'ISO_OUT',   X0+8400, Y0+250);

    PlaceNetLabel(SchDoc, 'MCU_GPIO',  X0+9000, Y0+250);

    PlaceTextFrame(SchDoc,
      'Universal 24V PNP/NPN pulse tap: high-impedance divider (~20uA @24V) + comparator + digital isolator + isolated DC/DC.',
      X0, Y0+800);

  finally
    SchServer.ProcessControl.PostProcess(SchDoc, '');
    SchDoc.GraphicallyInvalidate;
  end;
end;

begin
  Main;
end.

